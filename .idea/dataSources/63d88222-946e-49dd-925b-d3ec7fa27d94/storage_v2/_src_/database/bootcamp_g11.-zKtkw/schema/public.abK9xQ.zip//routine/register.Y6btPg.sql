create function register(i_email character varying, i_full_name character varying, i_age integer, i_password character varying, OUT o_message character varying, OUT o_success boolean) returns record
    language plpgsql
as
$$
declare
x_count integer:=0;

begin
select email into x_count from users where email=i_email;
if x_count>0 then
o_success:=false;
o_message:='Bunday user mavjud!';
else
insert into users(email,full_name,age,password) values(i_email,i_full_name,i_age,i_password);
o_success:=true;
o_message:='Saved!';
end if;
end;
$$;

alter function register(varchar, varchar, integer, varchar, out varchar, out boolean) owner to postgres;

